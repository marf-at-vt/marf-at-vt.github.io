#Nile: Measurements of the annual flow of the river at Ashwan 1871-1970
#Data available in R, taken from Durbin & Koopman (2001) Time Series
#Analysis of State Space models. The data are analyzed using the
#dlm package in Petris, Petrone & Campagnoli (2009)

library(dlm)
par(mfrow=c(1,1),bty='n',ps=14)
plot(Nile,col='darkblue',xlab="time",ylab="level",lwd=2,main="Nile River Level")
points(Nile,pch='*',col='darkblue')

#Model 1: {1,1,15100,755}
model_1=dlmModPoly(order=1,dV=15100,dW=755)
NileShort=ts(Nile[1:95],start=1871,freq=1)
NileFilt_1=dlmFilter(NileShort,model_1)
postmean_1=ts(c(dropFirst(NileFilt_1$m),rep(NA,5)),start=1871,freq=1)
postsd_1=ts(c(NileFilt_1$D.C,rep(NA,5)),start=1871,freq=1)
postsd_1_forecast=postsd_1+sqrt(model_1$V)
lines(postmean_1,col='red',lwd=2)
lines(postmean_1+1.96*postsd_1,lty=2,col='red')
lines(postmean_1-1.96*postsd_1,lty=2,col='red')


#Model 2: {1,1,15100,7550}
par(mfrow=c(1,1),bty='n',ps=14)
plot(Nile,col='darkblue',xlab="time",ylab="level",lwd=2,main="Nile River Level")
points(Nile,pch='*',col='darkblue')

model_2=dlmModPoly(order=1,dV=15100,dW=7550)
NileFilt_2=dlmFilter(NileShort,model_2)
postmean_2=ts(c(dropFirst(NileFilt_2$m),rep(NA,5)),start=1871,freq=1)
postsd_2=ts(c(NileFilt_2$D.C,rep(NA,5)),start=1871,freq=1)
lines(postmean_2,col='red',lwd=2)
lines(postmean_2+1.96*postsd_2,lty=2,col='red')
lines(postmean_2-1.96*postsd_2,lty=2,col='red')

#Model 3: {1,1,v,w} with MLEs for v and w.

build=function(param){
dlmModPoly(order=1,dV=exp(param[1]),dW=exp(param[2]))}
fit=dlmMLE(NileShort,rep(0,2),build)
#Note that the MLEs are V=15497.699  and W=1213.506

#Model 4: {1,1,v,v100}
model_4=dlmModPoly(order=1,C0=10^7,dV=1000,dW=100)
NileFilt_4=dlmFilter(NileShort,model_4)
n0=1; d0=10
out=residuals(NileFilt_4)
beta=d0+cumsum(out$res^2)/2
alpha=(n0+1)+(1:length(NileShort))/2
Ctilde=unlist(dlmSvd2var(NileFilt_4$U.C,NileFilt_4$D.C))[-1]
prob=0.975
tt=qt(prob,df=2*alpha)
lower_4=ts(c(dropFirst(NileFilt_4$m)-tt*sqrt(Ctilde*beta/alpha),rep(NA,5)),start=1871,freq=1)
upper_4=ts(c(dropFirst(NileFilt_4$m)+tt*sqrt(Ctilde*beta/alpha),rep(NA,5)),start=1871,freq=1)
par(mfrow=c(1,2),bty='n',ps=14)
plot(Nile,col='white',xlab="time",ylab="level",lwd=2,main="Nile River Level",
ylim=range(c(lower_4[-1],upper_4[-1],as.double(Nile)),na.rm=TRUE))
postmean_4=ts(c(dropFirst(NileFilt_4$m),rep(NA,5)),start=1871,freq=1)
lines(postmean_4,col='red',lwd=2)
lines(lower_4,lty=2,col='red')
lines(upper_4,lty=2,col='red')
points(Nile,col='darkblue',pch="*",cex=2)
hist(1/rgamma(5000,alpha[95],beta[95]),col='lightblue',xlab="v",
prob=TRUE,main=expression(paste('p(','v','|',D[T],')')))



# FORECASTING UNDER DIFFERENT MODELS...

par(mfrow=c(1,1),bty='n')
NileFor_1=dlmForecast(NileFilt_1,nAhead=5)
NileFor_2=dlmForecast(NileFilt_2,nAhead=5)
NileFor_4=dlmForecast(NileFilt_4,nAhead=5)
forecastmean_1=ts(c(rep(NA,94),postmean_1[95],NileFor_1$a),start=1871,freq=1)
forecastsd_1=ts(c(rep(NA,95),sqrt(as.double(NileFor_1$R))),start=1871,freq=1)
forecastmean_2=ts(c(rep(NA,94),postmean_2[95],NileFor_2$a),start=1871,freq=1)
forecastsd_2=ts(c(rep(NA,95),sqrt(as.double(NileFor_2$R))),start=1871,freq=1)
forecastmean_4=ts(c(rep(NA,94),postmean_4[95],NileFor_4$a),start=1871,freq=1)
forecastsd_4=ts(c(rep(NA,95),sqrt(beta[length(NileShort)]/alpha[length(NileShort)])*sqrt(as.double(NileFor_4$R))),start=1871,freq=1)

plot(Nile,col='white',xlab="time",ylab="level",lwd=2,main="Model 1",ylim=c(450,1500))
points(Nile,pch='*',col='darkblue',cex=2)
lines(postmean_1,lwd=2,col='red')
lines(postmean_1-1.96*postsd_1,lwd=1,col='red',lty=2)
lines(postmean_1+1.96*postsd_1,lwd=1,col='red',lty=2)
lines(forecastmean_1,lwd=2,col='darkgreen')
lines(forecastmean_1+1.96*forecastsd_1,lwd=1,col='darkgreen',lty=2)
lines(forecastmean_1-1.96*forecastsd_1,lwd=1,col='darkgreen',lty=2)

plot(Nile,col='white',xlab="time",ylab="level",lwd=2,main="Model 2",ylim=c(450,1500))
points(Nile,pch='*',col='darkblue',cex=2)
lines(postmean_2,lwd=2,col='red')
lines(postmean_2-1.96*postsd_2,lwd=1,col='red',lty=2)
lines(postmean_2+1.96*postsd_2,lwd=1,col='red',lty=2)
lines(forecastmean_2,lwd=2,col='darkgreen')
lines(forecastmean_2+1.96*forecastsd_2,lwd=1,col='darkgreen',lty=2)
lines(forecastmean_2-1.96*forecastsd_2,lwd=1,col='darkgreen',lty=2)


plot(Nile,col='white',xlab="time",ylab="level",lwd=2,main="Model 4",ylim=c(450,1500))
points(Nile,pch='*',col='darkblue',cex=2)
lines(postmean_4,lwd=2,col='red')
lines(lower_4,lwd=1,col='red',lty=2)
lines(upper_4,lwd=1,col='red',lty=2)
lines(forecastmean_4,lwd=2,col='darkgreen')
lines(forecastmean_4+qt(0.975,df=2*alpha[length(NileShort)])*forecastsd_4,lwd=1,col='darkgreen',lty=2)
lines(forecastmean_4-qt(0.975,df=2*alpha[length(NileShort)])*forecastsd_4,lwd=1,col='darkgreen',lty=2)


#SMOOTHING...
NileSmooth_1=dlmSmooth(NileFilt_1)
NileSmooth_2=dlmSmooth(NileFilt_2)
NileSmooth_4=dlmSmooth(NileFilt_4)
postmeansmooth_1=NileSmooth_1$s
postmeansmooth_2=NileSmooth_2$s
postmeansmooth_4=NileSmooth_4$s
par(mfrow=c(1,1),bty='n')
plot(NileShort,ylab="level",main="Nile River Level: Smoothing",lwd=1,col='gray')
points(NileShort,pch="*",cex=2,col='black')
lines(postmeansmooth_1,col='blue',lty=1,lwd=3)
lines(postmeansmooth_2,col='darkgreen',lty=1,lwd=3)
lines(postmeansmooth_4,col='magenta',lty=1,lwd=3)
leg=c("Model 1", "Model 2", "Model 4")
legend("bottomright",legend=leg,col=c('blue','darkgreen','magenta'),
lty=c(1,1,1),bty='n',lwd=c(3,3,3))


par(mfrow=c(1,3),bty='n')
plot(NileShort,ylab="level",main="Smoothing: Model 1",lwd=1,col='gray')
points(NileShort,pch="*",cex=2,col='black')
lines(postmeansmooth_1,col='blue',lty=1,lwd=3)
lowersmooth_1=postmeansmooth_1-1.96*sqrt(unlist(dlmSvd2var(NileSmooth_1$U.S,NileSmooth_1$D.S)))
uppersmooth_1=postmeansmooth_1+1.96*sqrt(unlist(dlmSvd2var(NileSmooth_1$U.S,NileSmooth_1$D.S)))
lines(lowersmooth_1,lty=2,lwd=2,col='blue')
lines(uppersmooth_1,lty=2,lwd=2,col='blue')



plot(NileShort,ylab="level",main="Smoothing: Model 2",lwd=1,col='gray')
points(NileShort,pch="*",cex=2,col='black')
lines(postmeansmooth_2,col='darkgreen',lty=1,lwd=3)
lowersmooth_2=postmeansmooth_2-1.96*sqrt(unlist(dlmSvd2var(NileSmooth_2$U.S,NileSmooth_2$D.S)))
uppersmooth_2=postmeansmooth_2+1.96*sqrt(unlist(dlmSvd2var(NileSmooth_2$U.S,NileSmooth_2$D.S)))
lines(lowersmooth_2,lty=2,lwd=2,col='darkgreen')
lines(uppersmooth_2,lty=2,lwd=2,col='darkgreen')

Stildelist=dlmSvd2var(NileSmooth_4$U.S,NileSmooth_4$D.S)
TT=length(NileShort)
pars=unlist(Stildelist)*(beta[TT]/alpha[TT])
tt=qt(0.975,df=2*alpha[TT])

plot(NileShort,ylab="level",main="Smoothing: Model 4",lwd=1,col='gray')
points(NileShort,pch="*",cex=2,col='black')
lines(postmeansmooth_4,col='magenta',lty=1,lwd=3)
lowersmooth_4=postmeansmooth_4-tt*sqrt(pars)
uppersmooth_4=postmeansmooth_4+tt*sqrt(pars)
lines(lowersmooth_4,lty=2,lwd=2,col='magenta')
lines(uppersmooth_4,lty=2,lwd=2,col='magenta')



