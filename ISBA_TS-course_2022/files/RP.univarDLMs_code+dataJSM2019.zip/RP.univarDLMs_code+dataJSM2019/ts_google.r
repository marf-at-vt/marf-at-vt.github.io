# Load data (entire world)
data=read.csv('timeseries_google.csv',header=TRUE)
data_ts=ts(data[,2],start=c(2004,1),frequency=12)
#
par(mfrow=c(1,1),bty='n',ps=12)
plot(data_ts,ylab="Google Volume Index",xlab="Time",lwd=2,col='darkblue',main="Search: time series")
points(data_ts,pch=19,cex=0.8,col='darkblue')
#
# Load data (US only)
data_us=read.csv('timeseries_google_onlyUS.csv',header=TRUE)
data_ts_us=ts(data_us[,2],start=c(2004,1),frequency=12)
plot(data_ts_us,ylab="Google Volume Index",xlab="Time",lwd=2,col='darkgreen',
main="Search: time series (only US)")
points(data_ts_us,pch=19,cex=0.8,col='darkgreen')

# Load dlm library
library(dlm)
# Model: Seasonal + linear trend 
#data=data_ts
data=data_ts_us
model_seasonal=dlmModTrig(s=12,q=6,dV=0,dW=1)
model_trend=dlmModPoly(order=2,dV=10,m0=c(20,0))
model=model_trend+model_seasonal
# Filtering
model_fit=dlmFilter(data,model)
# Smoothing
model_smooth=dlmSmooth(model_fit)
# 12 step-ahead forecast 
model_forecast=dlmForecast(model_fit,12)

# Extracting variances and means 
Ctilde=dlmSvd2var(model_fit$U.C,model_fit$D.C)
Ctilde_smooth=dlmSvd2var(model_smooth$U.S,model_smooth$D.S)
Ctilde=dropFirst(Ctilde)
Ctilde_smooth=dropFirst(Ctilde_smooth)
m_posterior=array(0,c(length(data),13,3))
m_posterior_smooth=array(0,c(length(data),13,3))
m_posterior_for=array(0,c(length(data),13,3))
ndata=length(data)
tt=qt(0.95,1:ndata)
#
for (j in 1:13){
m_posterior[,j,1]=dropFirst(model_fit$m[,j])
m_posterior_smooth[,j,1]=dropFirst(model_smooth$s[,j])}
#
for (i in 1:ndata){
for (j in 1:13){
m_posterior[i,j,2]=m_posterior[i,j,1]-tt[i]*sqrt(Ctilde[[i]][j,j])
m_posterior[i,j,3]=m_posterior[i,j,1]+tt[i]*sqrt(Ctilde[[i]][j,j])
m_posterior_smooth[i,j,2]=m_posterior_smooth[i,j,1]-tt[i]*sqrt(Ctilde_smooth[[i]][j,j])
m_posterior_smooth[i,j,3]=m_posterior_smooth[i,j,1]+tt[i]*sqrt(Ctilde_smooth[[i]][j,j])
}}

# Filtering and prediction (12 step-ahead)
par(mfrow=c(1,1),ps=12)
mfit=(model_fit$f)
mfor=model_forecast$f
timeseq=time(ts(c(mfit,mfor),start=2004,freq=12))
plot(timeseq,data,pch=19,cex=0.5,ylab="Google Volume Index",
     ylim=c(-10,150),main="Search: time series",xlab="",col="gray")
lines(ts(c(mfit,mfor),start=2004,freq=12),col='darkblue',lwd=3)
lines(ts(c(rep(NA,ndata),mfor),start=2004,freq=12),lwd=3,col='darkgreen')
ufit=model_fit$f+qnorm(0.25)*residuals(model_fit)$sd
ufor=model_forecast$f+qnorm(0.25)*sqrt(as.double(model_forecast$Q))
lfit=model_fit$f-qnorm(0.25)*residuals(model_fit)$sd
lfor=model_forecast$f-qnorm(0.25)*sqrt(as.double(model_forecast$Q))
lines(ts(c(ufit,ufor),start=2004,freq=12),lty=2,col='darkblue')
lines(ts(c(lfit,lfor),start=2004,freq=12),lty=2,col='darkblue')
lines(ts(c(rep(NA,ndata),lfor),start=2004,freq=12),lty=2,col='darkgreen',lwd=2.5)
lines(ts(c(rep(NA,ndata),ufor),start=2004,freq=12),lty=2,col='darkgreen',lwd=2.5)
leg=c("one-step-ahead","50% prediction interval","12-steps-ahead")
legend(x=2006,y=165,legend=leg,col=c('darkblue','darkblue','darkgreen'),
lty=c(1,2,1),bty='n',lwd=c(2,1,2))

# Smoothing estimates: Seasonal components 
par(mfrow=c(2,3))
for (i in c(3,5,7,9,11,13)){
plot(ts(c(m_posterior_smooth[1:ndata,i,1]),start=c(2003,12),freq=12),type='l',col='blue',lwd=2,
ylab="Google Volume Index",xlab="",ylim=c(-15,15))
lines(ts(c(m_posterior_smooth[1:ndata,i,2]),start=c(2003,12),freq=12),lwd=2,lty=3,col='blue')
lines(ts(c(m_posterior_smooth[1:ndata,i,3]),start=c(2003,12),freq=12),lwd=2,lty=3,col='blue')
abline(v=2004:2016+0.833,lty=3,col='darkgray')
}

# Smoothing estimates: Trend 
par(mfrow=c(1,1))
plot(ts((m_posterior_smooth[1:ndata,1,1]+m_posterior_smooth[1:ndata,2,1]),
start=c(2003,12),freq=12),type='l',col='blue',lwd=5, ylab="Google Volume Index",ylim=c(0,80))
lines(ts((m_posterior_smooth[1:ndata,1,2]+m_posterior_smooth[1:ndata,2,2]),start=c(2003,12),freq=12),lwd=5,lty=3,col='blue')
lines(ts((m_posterior_smooth[1:ndata,1,3]+m_posterior_smooth[1:ndata,2,3]),start=c(2003,12),freq=12),lwd=5,lty=3,col='blue')
abline(v=2004:2016+0.833,lty=5,col='darkgray')
points(data,pch=19,cex=0.8,col='darkgray')

