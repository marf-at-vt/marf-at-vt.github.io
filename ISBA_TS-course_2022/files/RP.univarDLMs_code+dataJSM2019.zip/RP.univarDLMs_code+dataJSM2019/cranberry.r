data=read.csv('cranberry.csv',header=TRUE)
all=NULL
substr(as.character(data$Week[1]),start=1,stop=3)
substr(as.character(data$Week[]),start=9,stop=11)
years=as.character(2004:2011)
months=c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
n=length(data$cranberry)
for (i in 1:length(years)){
B=substr(as.character(data$Week[]),start=9,stop=11)==substr(years[i],2,4)
C=substr(as.character(data$Week[]),start=9,stop=11)==substr(years[i],3,4)
for (j in 1:12){
A=substr(as.character(data$Week[]),start=1,stop=3)==months[j]
all=c(all,(mean(data$cranberry[(A&(B|C))])))
}
}

all=ts(all,start=2004,freq=12)
par(mfrow=c(1,1),bty='n',ps=12,las=3,oma=c(3,2,3,2))
plot(data$cranberry,type='l',axes=FALSE,ylab="Google Index",
xlab="",main="Cranberry (Weekly)",lwd=2,col='deeppink3')
axis(1,(1:length(data$cranberry))[seq(1,length(data$cranberry),by=20)],data$Week[seq(1,length(data$cranberry),by=20)])
axis(2)

plot(all,type='l',ylab="Google Index",xlab="",main="Cranberry (Monthly)",
lwd=2,col='deeppink3')


#Static full seasonal factor model...

data=all[1:84]-mean(all[1:84])

library(dlm)

modelcranberry=dlmModTrig(s=12,q=6,dV=0.3,dW=0.01)
modelcranberry_fit=dlmFilter(data,modelcranberry)
modelcranberry_smooth=dlmSmooth(modelcranberry_fit)
modelcranberry_forecast=dlmForecast(modelcranberry_fit,nAhead=12)

Ctilde=dlmSvd2var(modelcranberry_fit$U.C,modelcranberry_fit$D.C)
Ctilde_smooth=dlmSvd2var(modelcranberry_smooth$U.S,modelcranberry_smooth$D.S)
Ctilde=dropFirst(Ctilde)
Ctilde_smooth=dropFirst(Ctilde_smooth)

m_posterior=array(0,c(length(data),11,3))
m_posterior_smooth=array(0,c(length(data),11,3))
m_posterior_for=array(0,c(length(data),11,3))

tt=qt(0.95,1:84)

for (j in 1:11){
m_posterior[,j,1]=dropFirst(modelcranberry_fit$m[,j])
m_posterior_smooth[,j,1]=dropFirst(modelcranberry_smooth$s[,j])}


for (i in 1:84){
for (j in 1:11){
m_posterior[i,j,2]=m_posterior[i,j,1]-tt[i]*sqrt(Ctilde[[i]][j,j])
m_posterior[i,j,3]=m_posterior[i,j,1]+tt[i]*sqrt(Ctilde[[i]][j,j])
m_posterior_smooth[i,j,2]=m_posterior_smooth[i,j,1]-tt[i]*sqrt(Ctilde_smooth[[i]][j,j])
m_posterior_smooth[i,j,3]=m_posterior_smooth[i,j,1]+tt[i]*sqrt(Ctilde_smooth[[i]][j,j])
}}

par(mfrow=c(1,1),oma=c(1,1,1,1),las=1)
mfit=(modelcranberry_fit$f)
mfor=modelcranberry_forecast$f
timeseq=time(ts(c(mfit,mfor),start=2004,freq=12))
plot(ts(c(mfit,mfor),start=2004,freq=12),type='l',ylim=c(-3,3),col='deeppink3',
lwd=2,ylab="Google Index")
lines(ts(c(rep(NA,84),mfor),start=2004,freq=12),lwd=2.5,col='green')
ufit=modelcranberry_fit$f+qnorm(0.25)*residuals(modelcranberry_fit)$sd
ufor=modelcranberry_forecast$f+qnorm(0.25)*sqrt(as.double(modelcranberry_forecast$Q))
lfit=modelcranberry_fit$f-qnorm(0.25)*residuals(modelcranberry_fit)$sd
lfor=modelcranberry_forecast$f-qnorm(0.25)*sqrt(as.double(modelcranberry_forecast$Q))
lines(ts(c(ufit,ufor),start=2004,freq=12),lty=2,col='deeppink3')
lines(ts(c(lfit,lfor),start=2004,freq=12),lty=2,col='deeppink3')
lines(ts(c(rep(NA,84),lfor),start=2004,freq=12),lty=2,col='green',lwd=2.5)
lines(ts(c(rep(NA,84),ufor),start=2004,freq=12),lty=2,col='green',lwd=2.5)
points(ts(all-mean(all),start=2004,freq=12),cex=1.2,pch="*")
leg=c("one-step-ahead","50% prediction interval","12-steps-ahead")
#legend(locator(),legend=leg,col=c('deeppink3','deeppink3','green'),
#lty=c(1,2,1),bty='n',lwd=c(2,1,2))
#dev.print(file='cranb_prediction.pdf',device=pdf,height=10,width=7,pointsize=14)

par(mfrow=c(2,3),oma=c(1,1,1,1),las=1)
timeseq=time(ts(m_posterior_smooth[1:84,1,2],start=c(2003,12),freq=12))
for (i in c(1,3,5,7,9,11)){
plot(ts(c(m_posterior_smooth[1:84,i,1]),start=c(2003,12),freq=12),type='l',ylim=c(-3,3),col='blue',lwd=2,
ylab="Google Index")
lines(ts(c(m_posterior_smooth[1:84,i,2]),start=c(2003,12),freq=12),lwd=2,lty=3,col='blue')
lines(ts(c(m_posterior_smooth[1:84,i,3]),start=c(2003,12),freq=12),lwd=2,lty=3,col='blue')
}


