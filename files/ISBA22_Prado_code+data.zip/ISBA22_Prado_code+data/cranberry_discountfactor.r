#Seasonal + trend model with a discount factor...
library(dlm)
data=read.csv('cranberry.csv',header=TRUE)
all=NULL
substr(as.character(data$Week[1]),start=1,stop=3)
substr(as.character(data$Week[]),start=9,stop=11)
years=as.character(2004:2011)
months=c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
n=length(data$cranberry)
for (i in 1:length(years)){
B=substr(as.character(data$Week[]),start=9,stop=11)==substr(years[i],2,4)
C=substr(as.character(data$Week[]),start=9,stop=11)==substr(years[i],3,4)
for (j in 1:12){
A=substr(as.character(data$Week[]),start=1,stop=3)==months[j]
all=c(all,(mean(data$cranberry[(A&(B|C))])))
}
}

modelcranberry=dlmModPoly(1,dV=0)+dlmModTrig(s=12,q=3,dV=1,dW=1)  
modelcranberry$C0=100*diag(7)
source('dlmFilterDF.R')
modelcranberry_filt=dlmFilterDF(all,modelcranberry,DF=0.87)
beta0=1; alpha0=2
########Filtering estimates
out=residuals(modelcranberry_filt)
beta=beta0+cumsum(out$res^2)/2
alpha=alpha0+(1:length(all))/2
Ctilde=(dlmSvd2var(modelcranberry_filt$U.C,modelcranberry_filt$D.C))[-1]
prob=0.975
tt=qt(prob,df=2*alpha)
lower=array(0,c(length(all),7))
upper=array(0,c(length(all),7))
mean=array(0,c(length(all),7))
for (t in 1:length(all)){
for (k in 1:7){
mean[t,k]=dropFirst(modelcranberry_filt$m)[t,k]
lower[t,k]=dropFirst(modelcranberry_filt$m)[t,k]-tt[t]*sqrt(Ctilde[[t]][k,k]*beta[t]/alpha[t])
upper[t,k]=dropFirst(modelcranberry_filt$m)[t,k]+tt[t]*sqrt(Ctilde[[t]][k,k]*beta[t]/alpha[t])
}
}
#Sum of theta components...
par(mfrow=c(1,1),bty='n',ps=14)
var_cov_matrix=rep(0,length=length(all))
mean_all=rep(0,length(all))
for (t in 1:length(all)){
mean_all[t]=mean[t,1]+mean[t,2]+mean[t,4]+mean[t,6]
var_cov_matrix[t]=Ctilde[[t]][1,1]+Ctilde[[t]][2,2]+Ctilde[[t]][4,4]+Ctilde[[t]][6,6]+2*Ctilde[[t]][1,2]+2*Ctilde[[t]][1,4]+
2*Ctilde[[t]][1,6]+2*Ctilde[[t]][2,4]+2*Ctilde[[t]][2,6]+2*Ctilde[[t]][4,6]
}
plot(ts(mean_all,start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main="Filtering Estimates") 
lines(ts(mean_all+tt*sqrt(var_cov_matrix*beta/alpha),start=c(2004,1),freq=12),lty=2)
lines(ts(mean_all-tt*sqrt(var_cov_matrix*beta/alpha),start=c(2004,1),freq=12),lty=2)
points(ts(all,start=c(2004,1),freq=12),col='magenta',pch="*",cex=2)

par(mfrow=c(1,1),bty='n',ps=14)
plot(ts(mean[,1],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t1],'|',y[1:t],')'))) 
lines(ts(lower[,1],start=c(2004,1),freq=12),lty=2)
lines(ts(upper[,1],start=c(2004,1),freq=12),lty=2)

plot(ts(mean[,2],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t2],'|',y[1:t],')'))) 
lines(ts(lower[,2],start=c(2004,1),freq=12),lty=2)
lines(ts(upper[,2],start=c(2004,1),freq=12),lty=2)

plot(ts(mean[,4],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t4],'|',y[1:t],')'))) 
lines(ts(lower[,4],start=c(2004,1),freq=12),lty=2)
lines(ts(upper[,4],start=c(2004,1),freq=12),lty=2)

plot(ts(mean[,6],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t6],'|',y[1:t],')'))) 
lines(ts(lower[,6],start=c(2004,1),freq=12),lty=2)
lines(ts(upper[,6],start=c(2004,1),freq=12),lty=2)

###ONE-STEP-AHEAD FORECASTS
sigma2=c(beta0/(alpha0-1),beta/(alpha-1))
qt=out$sd^2*sigma2[-length(sigma2)]
alpha0T=c(alpha0,alpha)
tt=qt(prob,df=2*alpha0T[-length(alpha0T)])
parf=c(beta0/alpha0,beta/alpha)
parf=parf[-length(parf)]*out$sd^2
lower_f=(modelcranberry_filt$f)-tt*sqrt(parf)
upper_f=(modelcranberry_filt$f)+tt*sqrt(parf)
par(mfrow=c(1,1),bty='n',ps=14)
plot(ts(all,start=c(2004,1),freq=12),pch="*",col='white',ylim=c(-1,3.5),ylab="Goggle Index",
main=expression(paste('(',y[t+1],'|',y[1:t],')'))) 
points(ts(all,start=c(2004,1),freq=12),pch="*",col='magenta',cex=2)
lines(ts(modelcranberry_filt$f,start=c(2004,1),freq=12),lwd=2)
lines(ts(lower_f,start=c(2004,1),freq=12),lty=2)
lines(ts(upper_f,start=c(2004,1),freq=12),lty=2)

#SMOOTHING ESTIMATES...
modelcranberry_filt$mod$JFF=matrix(c(1,1,0,1,0,1,0),nr=1)
modelcranberry_filt$mod$JW=array(0,c(7,7))
modelcranberry_filt$mod$JW[1,]=1:7
modelcranberry_filt$mod$JW[2,]=8:14
modelcranberry_filt$mod$JW[3,]=15:21
modelcranberry_filt$mod$JW[4,]=22:28
modelcranberry_filt$mod$JW[5,]=29:35
modelcranberry_filt$mod$JW[6,]=36:42
modelcranberry_filt$mod$JW[7,]=43:49
X=unlist(dlmSvd2var(modelcranberry_filt$U.W,modelcranberry_filt$D.W))
modelcranberry_filt$mod$X=matrix(X,ncol=49,byrow=T)
modelcranberry_smooth=dlmSmooth(modelcranberry_filt)

TT=length(all)
Stilde=dropFirst(dlmSvd2var(modelcranberry_smooth$U.S,modelcranberry_smooth$D.S))
prob=0.975
tt=qt(prob,df=2*alpha[TT])
lower_s=array(0,c(length(all),7))
upper_s=array(0,c(length(all),7))
mean_s=array(0,c(length(all),7))
for (t in 1:length(all)){
for (k in 1:7){
mean_s[t,k]=dropFirst(modelcranberry_smooth$s)[t,k]
lower_s[t,k]=dropFirst(modelcranberry_smooth$s)[t,k]-tt*sqrt(Stilde[[t]][k,k]*beta[TT]/alpha[TT])
upper_s[t,k]=dropFirst(modelcranberry_smooth$s)[t,k]+tt*sqrt(Stilde[[t]][k,k]*beta[TT]/alpha[TT])
}
}


par(mfrow=c(1,1),bty='n',ps=14)
var_cov_matrix_s=rep(0,length=length(all))
mean_all_s=rep(0,length(all))
for (t in 1:length(all)){
mean_all_s[t]=mean_s[t,1]+mean_s[t,2]+mean_s[t,4]+mean_s[t,6]
var_cov_matrix_s[t]=Stilde[[t]][1,1]+Stilde[[t]][2,2]+Stilde[[t]][4,4]+Stilde[[t]][6,6]+2*Stilde[[t]][1,2]+2*Stilde[[t]][1,4]+
2*Stilde[[t]][1,6]+2*Stilde[[t]][2,4]+2*Stilde[[t]][2,6]+2*Stilde[[t]][4,6]
}
plot(ts(mean_all_s,start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main="Smoothing Estimates") 
lines(ts(mean_all_s+tt*sqrt(var_cov_matrix_s*beta[TT]/alpha[TT]),start=c(2004,1),freq=12),lty=2)
lines(ts(mean_all_s-tt*sqrt(var_cov_matrix_s*beta[TT]/alpha[TT]),start=c(2004,1),freq=12),lty=2)
points(ts(all,start=c(2004,1),freq=12),col='magenta',pch="*",cex=2)

par(mfrow=c(1,1),bty='n',ps=14)
plot(ts(mean_s[,1],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t1],'|',y[1:T],')'))) 
lines(ts(lower_s[,1],start=c(2004,1),freq=12),lty=2)
lines(ts(upper_s[,1],start=c(2004,1),freq=12),lty=2)

plot(ts(mean_s[,2],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t2],'|',y[1:T],')'))) 
lines(ts(lower_s[,2],start=c(2004,1),freq=12),lty=2)
lines(ts(upper_s[,2],start=c(2004,1),freq=12),lty=2)

plot(ts(mean_s[,4],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t4],'|',y[1:T],')'))) 
lines(ts(lower_s[,4],start=c(2004,1),freq=12),lty=2)
lines(ts(upper_s[,4],start=c(2004,1),freq=12),lty=2)

plot(ts(mean_s[,6],start=c(2004,1),freq=12),type='l',ylim=c(-1,3.5),lwd=2,ylab="Goggle Index",main=expression(paste('(',theta[t6],'|',y[1:T],')'))) 
lines(ts(lower_s[,6],start=c(2004,1),freq=12),lty=2)
lines(ts(upper_s[,6],start=c(2004,1),freq=12),lty=2)

#CHOOSING THE OPTIMAL DISCOUNT FACTOR... 
gridsingle=seq(from=0.5,1.0,by=0.01)
model=dlmModPoly(1,dV=0)+dlmModTrig(s=12,q=3,dV=1,dW=0)  
i=1
msesingle=array(0,length(gridsingle))
for (disc in gridsingle){
modelfilter=dlmFilterDF(all,model,DF=disc)
aux=modelfilter$f-all
msesingle[i]=sum((aux)^2)/length(all)
i=i+1}
gridsingle[msesingle==min(msesingle)]

#COMPONENT DISCOUNT
source('dlmFilter_block.r')
grid1=seq(from=0.8,1,by=0.01)
grid2=seq(from=0.8,1,by=0.01)
model=dlmModPoly(1,dV=0)+dlmModTrig(s=12,q=3,dV=1,dW=0)  
model$C0=diag(7)
i=1
mse=array(0,c(length(grid1),length(grid2)))
for (disc1 in grid1){
j=1
for (disc2 in grid2){
modelfilter=dlmFilterDF_block(all,model,DF=c(disc1,disc2),dimDF=c(1,6))
aux=modelfilter$f[2:length(all)]-all[2:length(all)]
mse[i,j]=sum((aux)^2)/length(all)
j=j+1}
i=i+1}

par(mfrow=c(1,3),bty='n',ps=14)
plot(gridsingle,msesingle,type='l',xlab=expression(delta),ylab="MSE",main="Single Discount Factor",lwd=2)
points(1,min(msesingle),pch="*",cex=3,col='red')

image(grid1,grid2,mse,xlab=expression(delta[1]),ylab=expression(delta[2]),col=terrain.colors(500),main="Component Discounting")
contour(grid1,grid2,mse,lwd=2,cex=2,add=TRUE)
points(0.87,1,pch="*",cex=2)
text(0.96,1.00,expression(paste(delta[1],'=0.87',',',delta[2],'=1')))
#Fixing delta2=1 we have...
plot(grid1,mse[,21],main=expression(paste(delta[1],',',delta[2],'=1')),ylab="MSE",xlab=expression(delta[1]),type='l',lwd=2)
points(0.87,min(mse),cex=3,pch="*",col='red')

